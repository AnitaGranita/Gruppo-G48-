import { createRouter, createWebHistory } from 'vue-router'

export default router
