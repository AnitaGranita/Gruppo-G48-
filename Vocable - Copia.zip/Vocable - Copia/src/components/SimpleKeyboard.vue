<template>
    <div class="simple-keyboard"></div>
  </template>
  
  <script setup>
  import Keyboard from "simple-keyboard";
  import "simple-keyboard/build/css/index.css"
  
  import {ref, onMounted} from "vue";

  const emit = defineEmits(["onKeyPress"]);

  const keyboard = ref(null);

  const onKeyPress = (button) => {
    emit("onKeyPress", button);
  };

  onMounted(()=>{
    keyboard.value = new Keyboard("simple-keyboard",{
        layout: {
            default: [
                "q w e r t y u i p",
                "a s d f g h j k l",
                "{bksp} z x c v b n m {enter}",
                "{space}",
            ],
        },
        onKeyPress: onKeyPress,
    });
  });
  </script>