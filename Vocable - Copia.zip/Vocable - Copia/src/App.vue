<script setup>
import SimpleKeyboard from './components/SimpleKeyboard.vue';
import WordRow from './components/WordRow.vue';
import { reactive, onMounted } from 'vue';

const state = reactive({
  solution: "books",
  guesses: ["", "", "", "", ""],
  currentGuessIndex: 0,
});

const handleInput = (key) => {
  console.log(key);

  if(state.currentGuessIndex >=6){
    return;
  }
  
  const currentGuess = state.guesses[state.currentGuessIndex];
  console.log(currentGuess);
  if(key.enter){

  }else if(key.delete){
    state.guesses[state.currentGuessIndex] = currentGuess.slice(0,-1);
   // console.log(currentGuess);
  }//else if(currentGuess.lenght<6){
   // console.log(currentGuess);
  const alphaRegex = /[a-zA-Z]/;
    if(alphaRegex.test(key)){
      state.guesses[state.currentGuessIndex] += key;
    }
 // }
  
  
  /*
  if(state.currentGuessIndex >=6){
    return;
  }
  const currentGuess = state.guesses[state.currentGuessIndex];

  if(key=="{enter}"){
    //SEND GUESS
  }else if(key=="{bksp}"){
    //viene rimossa l'ultima lettera quando si preme "backspace"
    state.guesses[state.currentGuessIndex] = currentGuess.slice(0,-1);
  }else if(currentGuess.lenght<6){
    //se la lettera appartiene all'alfabeto, aggiungila
    const alphaRegex = /[a-zA-Z]/;
    if(alphaRegex.test(key)){
      state.guesses[state.currentGuessIndex] += key;
    }
  }*/
};

onMounted(() =>{
  window.addEventListener("keyup", (e) => {
    e.preventDefault();
   /* let key =
      e.enter == 13
      ? "{enter}"
      : e.delete== 8
      ? "{bksp}"
      : e.space == 32 //e.keyCode == 32
      ? "{space}"
      : String.fromCharCode(e.keyCode).toLocaleLowerCase();*/
      let key = String.fromCharCode(e.keyCode).toLocaleLowerCase();
    handleInput(key);

  });
});

</script>


<template>

  <div class="flex flex-col h-screen max-w-md mx-auto justify-evenly">
    <div>
      <word-row
        v-for ="(guess,i) in state.guesses"
        :key="i"
        :value="guess"
        :solution="state.solution"
        :submitted="i<state.currentGuessIndex"
      />
    </div>
    <simple-keyboard @onKeyPress="handleInput"/>
  </div>
  
</template>