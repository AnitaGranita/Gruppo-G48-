<template>
    <div>
      <h1>About Page</h1>
      <linechart />
    </div>
  </template>
  
    
    <script>
    import linechart from './LineChart.vue'
  
  export default {
    components: {
      linechart,
    },
    }
    </script>