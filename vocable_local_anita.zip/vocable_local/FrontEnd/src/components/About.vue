<template>
  <div>
    <h2>About us</h2>
    <h1>‎</h1>
    <h1>Il nostro team è composto da 3 studenti UniTN che lavorano al progetto</h1>
    <h1>‎</h1>
    <h3>Anita Scortegagna</h3>
    <h1>[anita.scortegagna@studenti.unitn.it]</h1>
    <h3>Pietro Tabladini</h3>
    <h1>[pietro.tabladini@studenti.unitn.it]</h1>
    <h3>Pietro Mazzocco</h3>
    <h1>[pietro.mazzocco@studenti.unitn.it]</h1>
    <h1>‎</h1>
    <h4>Se incontri un bug, non esitare a contattarci!</h4>
  </div>
</template>

  
  <script>

export default{
  }
  </script>

<style scoped>
h1 {
    text-align:center;
}
h2 {
  font-weight: bold;
  font-size:xx-large;
  text-align: center;
  color: #050780;
}
h3 {
font-size: larger;
font-weight: bold;
text-align: center;
color:black;
}
h4{
  font-size: large;
  font-weight: bold;
  text-align: center;
  color: red;
}
</style>