<template>
    <div id="IconLogo">
      <img :src="image" />
    </div>
  </template>
  
  <script>
  
  export default {
    data: function () {
      return {
        link: '../../assets/logo.png'
      }
    }
  }
  
  </script>
  