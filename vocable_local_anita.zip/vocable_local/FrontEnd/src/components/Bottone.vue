<template>
    <button class="bg-blue-300 hover:bg-blue-500 duration-300 font-sm text-white rounded py-1.5 px-4">
        <slot></slot>
    </button>
</template>