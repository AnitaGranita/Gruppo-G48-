<script setup>
import { stringifyQuery } from 'vue-router';
import SimpleKeyboard from './components/SimpleKeyboard.vue';
import WordRow from './components/WordRow.vue';
import { reactive, onMounted, computed } from 'vue';

const state = reactive({
  solution: "monkeysss", 
  guesses: ["", "", "", "", "", ""], 
  currentGuessIndex: 0,
  guessedLetters: {
    miss: [],
    found: [],
    hint: [],
  },
});

const wonGame = computed( //valore che ti dice se hai vinto il gioco
  ()=>
    state.guesses[state.currentGuessIndex - 1] === state.solution
);

const lostGame = computed(()=> !wonGame.value //valore che ti dice se hai perso 
  && state.currentGuessIndex >= 6
);

const handleInput = (key) => {  //funzione che gestisce gl'input della tastiera
  //console.log(key);
  if (state.currentGuessIndex >= 6 || wonGame.value) { //se hai finito i tentativi o hai vinto, return
    return;
  }
  const currentGuess = state.guesses[state.currentGuessIndex];  //currentGuess è l'elemento dell'array delle guess attuale
  if (key=="{enter}"){  //come primo controllo, si verifica se il pulsante di invio è stato schiacciato
    if (currentGuess.length == state.solution.length) {  //controlla poi che la lunghezza della guess sia uguale a quella della soluzione
      state.currentGuessIndex++;  //viene aggiornato l'index
      for (var i = 0; i < currentGuess.length; i++) { //il for smista le lettere trovate, assenti e nella posizione sbagliata nei vari arrai corrispondenti
        let c = currentGuess.charAt(i);
        if  (c==state.solution.charAt(i)) { 
          state.guessedLetters.found.push(c); //array lettere trovate
        } else if (state.solution.indexOf(c)!=-1) {
          state.guessedLetters.hint.push(c);  //array lettere pos. sbagliata
        } else {
          state.guessedLetters.miss.push(c);  //array lettere assenti
           //console.log(state.guessedLetters.miss);
        }
      }
    }
  } else if (key=="{bksp}") { //se viene premuto il pulsate "backspace" viene tolto l'ultimo carattere
    state.guesses[state.currentGuessIndex] =
    currentGuess.slice(0, -1);
  } else if (currentGuess.length < state.solution.length) { //se viene inserito un altro carattere si controlla che sia alfanumerico
    const alphaRegex = /[a-zA-Z]/;
    if (alphaRegex.test(key)) { 
      state.guesses[state.currentGuessIndex] += key;
    }
  }
};

onMounted(() =>{ 
  window.addEventListener("keyup", (e) => {  //se usi la tastiera a schermo, restituisce le lettere come se fossero inserite da tastiera
    e.preventDefault();
    let key =
      e.code == "Enter"
      ? "{enter}"
      : e.code== "Backspace"
      ? "{bksp}"
      :e.key.toLowerCase();
      handleInput(key);
  });
});

</script>


<template>

  <div class="flex flex-col h-screen max-w-md mx-auto justify-evenly">
    <div>
      <word-row
        v-for ="(guess,i) in state.guesses"
        :key="i"
        :value="guess"
        :solution="state.solution"
        :submitted="i<state.currentGuessIndex"
        
      />
    </div>
    <p v-if="wonGame" class="text-center">
      Congratulations! Solution found :D
    </p>
    <p v-else-if="lostGame" class="text-center">
      Out of tries. :(
    </p>
    <simple-keyboard @onKeyPress="handleInput"
    :guessedLetters="state.guessedLetters"
    />
  </div>
  
</template>